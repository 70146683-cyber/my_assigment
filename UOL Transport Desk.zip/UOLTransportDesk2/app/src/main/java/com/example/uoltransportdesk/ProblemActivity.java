package com.example.uoltransportdesk;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProblemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_problem);

        TextView tvGreeting =
                findViewById(R.id.tvGreeting);

        EditText etDriverPhone =
                findViewById(R.id.etDriverPhone);

        EditText etEmail =
                findViewById(R.id.etEmail);

        Button btnCallDriver =
                findViewById(R.id.btnCallDriver);

        Button btnSendEmail =
                findViewById(R.id.btnSendEmail);


        String name =
                getIntent().getStringExtra(
                        MainActivity.EXTRA_NAME
                );


        if (name == null || name.trim().isEmpty()) {

            name = "Student";
        }


        tvGreeting.setText(
                "Hello, " + name +
                        "! Tell us what went wrong."
        );


        btnCallDriver.setOnClickListener(v -> {

            String number =
                    etDriverPhone.getText()
                            .toString()
                            .trim();


            if (!number.matches("03\\d{9}")) {

                etDriverPhone.setError(
                        "Enter a valid 11-digit number starting with 03"
                );

                return;
            }


            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:" + number)
            );

            MainActivity.openIntent(
                    this,
                    intent
            );
        });


        btnSendEmail.setOnClickListener(v -> {

            String address =
                    etEmail.getText()
                            .toString()
                            .trim();


            if (!Patterns.EMAIL_ADDRESS
                    .matcher(address)
                    .matches()) {

                etEmail.setError(
                        "Enter a valid email address"
                );

                return;
            }


            Intent intent = new Intent(
                    Intent.ACTION_SENDTO,
                    Uri.parse("mailto:" + address)
            );

            MainActivity.openIntent(
                    this,
                    intent
            );
        });
    }
}